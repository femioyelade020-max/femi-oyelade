const KEY='femiOyeladePortfolioV2';
const defaults=[
 {title:'Civil Engineering Journey',issuer:'Abiola Ajimobi Technical University',year:'2026',category:'University',description:'Studying Civil Engineering and building a strong foundation for a career in infrastructure and problem-solving.'},
 {title:'NICESA — PRO II',issuer:'Civil Engineering Students Association',year:'2026',category:'Leadership',description:'Serving in a student leadership role while learning communication, responsibility and service.'},
 {title:'Building at the intersection',issuer:'Personal Projects',year:'2026',category:'Project',description:'Exploring how engineering, technology and digital tools can work together to solve practical problems.'}
];
const grid=document.getElementById('achievementGrid');
const modal=document.getElementById('editorModal');
function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function getData(){try{return JSON.parse(localStorage.getItem(KEY))||defaults}catch{return defaults}}
function render(){grid.innerHTML=getData().map(a=>`<article class="achievement"><span class="tag">${escapeHtml(a.category)}</span><h3>${escapeHtml(a.title)}</h3><p>${escapeHtml(a.description||'')}</p><div class="meta">${escapeHtml(a.issuer)} · ${escapeHtml(a.year)}</div></article>`).join('')}
function open(){modal.classList.add('show');modal.setAttribute('aria-hidden','false')}
function close(){modal.classList.remove('show');modal.setAttribute('aria-hidden','true')}
document.getElementById('openEditor').onclick=open;document.getElementById('addAchievement').onclick=open;document.getElementById('closeEditor').onclick=close;
modal.addEventListener('click',e=>{if(e.target===modal)close()});
document.getElementById('achievementForm').addEventListener('submit',e=>{e.preventDefault();const f=new FormData(e.target);const data=getData();data.push(Object.fromEntries(f.entries()));localStorage.setItem(KEY,JSON.stringify(data));render();e.target.reset();close()});
document.getElementById('resetDemo').onclick=()=>{localStorage.setItem(KEY,JSON.stringify(defaults));render()};
document.getElementById('year').textContent=new Date().getFullYear();render();
